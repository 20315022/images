# maïsMaladie > 2022-08-25 11:49pm
https://universe.roboflow.com/object-detection/maismaladie

Provided by Roboflow
License: CC BY 4.0

