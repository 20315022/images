# maïsPb > 2022-08-25 10:29pm
https://universe.roboflow.com/object-detection/maispb

Provided by Roboflow
License: CC BY 4.0

